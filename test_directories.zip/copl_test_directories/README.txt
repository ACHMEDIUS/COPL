Expected directory structure:

repository root/
|-- assignment 1/
|   |-- Makefile
|   |-- positives.txt
|   |-- // rest of your code
|   |-- // structured as you see fit
|-- assignment 2/
|   |-- Makefile
|   |-- positives.txt
|   |-- // rest of your code
|   |-- // structured as you see fit
|-- assignment 3/
    |-- Makefile
    |-- positives.txt
    |-- // rest of your code
    |-- // structured as you see fit


Run the scripts from the root of your repository using

bash test_directory_structure.sh | bash summarize_dir_test.sh

to test whether your repository complies to this structure.
