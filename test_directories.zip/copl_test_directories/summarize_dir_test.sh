#!/bin/bash
# samenvatten comply info
# vat verschillende records samen tot simpelere tekst
sed -E -e 's/ASS([1-3])RUNTARGET,ASS\1BUILDTARGET,ASS\1MAKEFILE/ASS\1COMPLY/g' \
 -e 's/ASS1MAP,ASS2MAP,ASS3MAP/Heeft alle assignment mappen aangemaakt/' \
 -e 's/ASS1MAKEFILE,ASS2MAKEFILE,ASS3MAKEFILE/Heeft voor iedere assignment een Makefile/'| \
 sed 's/ASS1COMPLY,ASS2COMPLY,ASS3COMPLY/Complies/'|\
 sed -E 's/,ASS([1-3])MAP,ASS([1-3])MAP/, mappen voor assignment \1 en \2 aangemaakt/'|\
 sed -Ee 's/ASS([1-3])MAKEFILE,ASS([1-3])MAKEFILE/ Makefile voor assignment \1 en \2/' |\
 sed -Ee 's/ASS([1-3])COMPLY,ASS([1-3])COMPLY/\1 en \2 complies/' \
  -e  's/ASS([1-3])MAP/map voor assignment \1 aangemaakt/' \
  -e 's/ASS([1-3])MAKEFILE/ Makefile voor assignment \1/' \
  -e 's/ASS([1-3])COMPLY/1 complies/' |\
  sed 's/,$//'
